# RYNEX INDIA – Super Admin Panel
React + Vite admin panel (hash routing) with a Cloudflare Worker + Firebase backend. See `DEPLOY.md` for exact deployment steps for Cloudflare Pages and Netlify, and `TEST_REPORT.md` for what was and was not tested.

    npm install
    npm run build      # output in dist/
    npm run dev
