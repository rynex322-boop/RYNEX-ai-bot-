import { api } from '../api/services.js';
import { useLoad } from '../hooks.js';
import { Card, PageHead, Gate, Badge } from '../components/UI.jsx';

const TILES = [
  ['pendingOrders', 'Pending orders'], ['approvedOrders', 'Approved orders'], ['rejectedOrders', 'Rejected orders'],
  ['totalCustomers', 'Customers'], ['activeSubscriptions', 'Active subscriptions'], ['expiringSoon', 'Expiring in 7 days'],
];
const CHECKS = [
  ['botToken', 'Telegram bot token'], ['firebase', 'Firebase service account'], ['firebaseApiKey', 'Firebase web API key'],
  ['adminUid', 'Admin UID'], ['adminOrigin', 'Admin origin (CORS)'], ['mediaBucket', 'R2 media bucket'],
  ['r2PublicUrl', 'R2 public URL'], ['adminChatId', 'Admin chat ID (order alerts)'],
];

export default function Dashboard() {
  const st = useLoad(api.stats);
  const hs = useLoad(api.health);
  return (
    <>
      <PageHead title="Dashboard" sub="Live numbers come from your backend." />
      <Gate st={st} keepOnPending what="statistics">
        {(d) => (
          <div className="grid tiles">
            {TILES.map(([k, label]) => (
              <Card key={k} className="tile"><div className="num">{d?.[k] ?? '—'}</div><div className="lbl">{label}</div></Card>
            ))}
          </div>
        )}
      </Gate>
      <Card title="Backend configuration">
        {hs.loading ? <div className="empty">Checking…</div> : hs.error ? <div className="note err">{hs.error}</div> : (
          <ul className="status">
            {CHECKS.map(([k, m]) => (
              <li key={m}><span>{m}</span><Badge tone={hs.data?.[k] ? 'ok' : 'err'}>{hs.data?.[k] ? 'Set' : 'Missing'}</Badge></li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
