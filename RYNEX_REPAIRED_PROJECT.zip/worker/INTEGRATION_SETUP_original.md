# RYNEX INDIA – Admin + Telegram integration pack

This pack includes the supplied React admin frontend plus a Cloudflare Worker backend (`worker.js`). The requested line remains exactly:

```js
const ADMIN_ID = "plz join teligram";
```

## Important status
This is integration source, not a deployed/live system. It cannot work until the Cloudflare Worker secrets, R2 binding, Firebase service account, Firebase Auth admin UID, CORS origin, Telegram webhook, and Firestore setup below are configured. Test with a small non-production order first. Payment screenshots are never auto-approved; verify the actual UPI/bank transaction manually.

## 1. Firebase
Use the existing Firebase project `rynex-ai-chatbot`.

1. Confirm Firestore is enabled.
2. In Firebase Console → Project settings → Service accounts, generate a private key JSON. Keep it private; do not send it in chat or put it in the frontend.
3. Firebase Authentication → Users: ensure the admin email/password account exists. The UID must match the configured `ADMIN_UID`.
4. Firestore collections are created automatically on first write: `system/config`, `orders`, `customers`, `media`, `sessions`.
5. For production, restrict who can access Firestore directly. The Worker uses a service account, so Firestore client rules do not protect server writes. Keep the service account key only in Worker secrets.

## 2. Cloudflare Worker
Create/choose the existing Worker `rynex-telegram-bot`. Upload `worker.js` as its module source.

Add an R2 bucket binding named exactly `MEDIA_BUCKET` to your Worker. Configure a public R2 custom domain for that bucket and set `R2_PUBLIC_BASE_URL` to that HTTPS base URL (without trailing slash). This is needed for the QR image to display in the panel and for the bot to send QR images. Media delivery to Telegram is performed by the Worker from R2.

Set these Worker variables/secrets:

- `BOT_TOKEN` (Secret): existing Telegram bot token. Never expose it in the frontend.
- `FIREBASE_SERVICE_ACCOUNT` (Secret): entire service-account JSON on one line.
- `FIREBASE_WEB_API_KEY` (Variable): Firebase Web API key from the existing web app config.
- `FIREBASE_PROJECT_ID` (Variable): `rynex-ai-chatbot`.
- `ADMIN_UID` (Variable): authorized Firebase admin user's UID.
- `ADMIN_ORIGIN` (Variable): exact deployed Admin Panel origin, e.g. `https://your-admin.pages.dev`.
- `R2_PUBLIC_BASE_URL` (Variable): public R2 custom domain.
- `ADMIN_CHAT_ID` (Variable): Telegram numeric chat ID to receive new order alerts. This is separate from the requested `ADMIN_ID` placeholder constant.
- `UPI_ID` (Variable, optional): payment UPI ID; set only if you want to display it in future payment-message enhancements.
- `SUPPORT_URL` (Variable, optional): Telegram support link, e.g. `https://t.me/your_support`.

Do not paste BOT_TOKEN or service-account private key into GitHub, source code, `.env`, or the browser.

## 3. Telegram webhook
After deploying the Worker, set the Telegram webhook to:

`https://YOUR-WORKER.workers.dev/telegram/webhook`

Use Telegram's `setWebhook` method from a private environment. Do not share the bot token in public. If the webhook is already set to the Worker root URL, update it to the `/telegram/webhook` path.

## 4. Admin panel
In the React project, copy `.env.example` to `.env` and set:

`VITE_API_BASE_URL=https://YOUR-WORKER.workers.dev`

Then run:

```bash
npm install
npm run build
```

Upload the generated `dist/` folder to Cloudflare Pages. Set the deployed Pages origin exactly in Worker variable `ADMIN_ORIGIN`.

## 5. First checks
1. Sign in with the Firebase admin email/password whose UID equals `ADMIN_UID`.
2. Open Prices, confirm default plans appear; save a harmless test change and verify the bot's plan menu.
3. Upload a small QR image and one short demo video.
4. Test `/start`, plan selection, payment reference, and screenshot using a second Telegram account.
5. Confirm the pending order appears in Admin → Orders.
6. Verify the real payment independently before clicking Approve. Confirm delivery is correct for Android/iOS.

## Known limitations to resolve before public launch
- The `ADMIN_ID` constant is deliberately preserved as requested. It is a literal placeholder string, not a valid Telegram numeric user ID. The separate `ADMIN_CHAT_ID` variable is used for admin order alerts.
- `Lifetime` is represented as 36,500 days in the current plan editor; the frontend stores durations in days, not a special lifetime type. For exact no-expiry semantics, treat plans named `Lifetime` specially in the Worker before production.
- This starter uses Telegram's temporary file download URL for payment screenshots. For long-term records, copy screenshots to R2 instead of relying on Telegram file URLs.
- The approval path should be hardened with a Firestore transaction/idempotency lock before real sales. Test that duplicate approve requests cannot double-deliver.
- The Worker uses service-account REST access and R2. Check your Cloudflare plan's request/upload limits for large APKs/videos; very large uploads should use direct-to-R2 presigned uploads.
- The iOS flow currently sends demo media only; no TestFlight link is configured in this admin panel.
- Do not treat a screenshot as proof of payment. Manually check bank/UPI transaction before approving.

## Rollback
Keep a copy of the currently deployed Worker before replacing it. If any test fails, restore that copy and keep the bot in maintenance mode until corrected.
