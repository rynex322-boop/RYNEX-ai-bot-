import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Same config works on Cloudflare Pages and Netlify: root "/", output "dist".
export default defineConfig({
  base: '/',
  plugins: [react()],
  build: { outDir: 'dist', target: 'es2018' },
});
