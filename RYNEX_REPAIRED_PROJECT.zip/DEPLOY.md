# RYNEX INDIA Admin – Deployment

Project layout (root = repository root, `package.json` is at the top level):

```
package.json  vite.config.js  index.html  netlify.toml  .env.production
public/_redirects  public/_headers
src/            React admin panel (hash routing)
worker/         Cloudflare Worker (worker.js) – deploy separately
```

## A. Cloudflare Pages
1. Put this project in a GitHub repo (or use Direct Upload of the built `dist/` folder).
2. Cloudflare Dashboard -> Workers & Pages -> Create -> Pages -> Connect to Git.
3. Framework preset: **Vite** | Build command: `npm run build` | Build output directory: `dist` | Root directory: `/` (leave empty).
4. Environment variable (optional, default is already in `.env.production`): `VITE_API_BASE_URL` = `https://rynex-telegram-bot.raunakkumarff779.workers.dev`
5. Deploy. Copy the final URL (e.g. `https://xxxx.pages.dev`).

## B. Netlify
1. Add new site -> Import from Git (same repo).
2. Base directory: empty (project root) | Build command: `npm run build` | Publish directory: `dist`. (`netlify.toml` already sets these and Node 20.)
3. Optional env var: `VITE_API_BASE_URL` (same value as above).
4. Deploy. Copy the URL (e.g. `https://xxxx.netlify.app`).

## C. Worker (separate from Pages/Netlify)
1. Cloudflare -> Workers & Pages -> `rynex-telegram-bot` -> Edit code -> paste `worker/worker.js` (or `wrangler deploy` with `worker/wrangler.toml.example` copied to `wrangler.toml`).
2. Settings -> Bindings -> add R2 bucket binding named exactly `MEDIA_BUCKET`; make the bucket publicly reachable (custom domain or r2.dev) and use that URL as `R2_PUBLIC_BASE_URL`.
3. Settings -> Variables and Secrets:

| Name | Type | Value |
|---|---|---|
| BOT_TOKEN | Secret | token of @RynexSalesBot |
| FIREBASE_SERVICE_ACCOUNT | Secret | full service-account JSON (one line) for `rynex-ai-chatbot` |
| FIREBASE_PROJECT_ID | Variable | `rynex-ai-chatbot` |
| FIREBASE_WEB_API_KEY | Variable | Firebase web API key |
| ADMIN_UID | Variable | UID of the Firebase admin user |
| ADMIN_ORIGIN | Variable | `https://xxxx.pages.dev,https://xxxx.netlify.app` (exact origins, comma separated, no trailing path) |
| R2_PUBLIC_BASE_URL | Variable | public URL of the R2 bucket |
| ADMIN_CHAT_ID | Variable | your numeric Telegram chat ID (order alerts) |
| TELEGRAM_WEBHOOK_SECRET | Secret (recommended) | any long random string |
| SUPPORT_URL, UPI_ID | Variable (optional) | |

4. Set the Telegram webhook (from any browser, replace values): 
   `https://api.telegram.org/bot<BOT_TOKEN>/setWebhook?url=https://rynex-telegram-bot.raunakkumarff779.workers.dev/telegram/webhook&secret_token=<TELEGRAM_WEBHOOK_SECRET>`
   Do not share this link publicly (it contains the bot token).

## D. Firebase
Authentication -> enable Email/Password, create the admin user, copy its UID into `ADMIN_UID`. Firestore must be enabled (collections `system`, `orders`, `customers`, `media`, `sessions` are created on first write). Keep Firestore client rules closed; only the Worker (service account) writes.

## E. First checks
Open the panel -> sign in -> Dashboard "Backend configuration" card should show every item as Set -> save a price -> upload QR -> test /start with a second Telegram account -> confirm the order appears as Pending -> verify the real payment -> Approve.

## Limits to know
- Telegram bots can upload files up to 50 MB; the panel and Worker enforce 45 MB for APK/video uploads.
- The Worker reads each uploaded file into memory before sending to Telegram; keep files small.
- Lifetime plans are stored as 36,500 days and treated as "no expiry".
